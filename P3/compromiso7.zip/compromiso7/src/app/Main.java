package app;

import java.util.Collections;
import java.util.Scanner;
import java.util.Vector;

import bintree.BinNode;
import tools.*;

public class Main {
	
	public static Vector<Character> tokens, kiwi;
	

	public static void main(String[] args) {
	    BinNode syntaxTree = new BinNode();
		
		Scanner scan = new Scanner(System.in);
		
		String test;
		
		test = scan.nextLine();
		
		tokens = Lexer.getTokens(test);

		Lexer.insertPropValues();

        scan.close();
		Lexer.printSymbolTable();
		
//		for(int i =0; i<tokens.size(); i++)
//		{
//			System.out.println(tokens.elementAt(i));
//		}
	
		
		Parser parser = new Parser(tokens, test);
		
		syntaxTree = parser.imp();

        System.out.println(BinNode.evaluateTree(syntaxTree, Lexer.getSymbolTable()));
		
		BinNode.printInorder(syntaxTree);
		
	}
	

}
