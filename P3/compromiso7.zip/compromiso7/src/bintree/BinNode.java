package bintree;

import java.util.HashMap;

/**
 * Clase que representa nodos de un árbol.
 */
public class BinNode {

    /**
     * Hijos izquierdos y derechos.
     */
	BinNode left, right;

    /**
     * Valor almacenado.
     */
	Character token;

    /**
     * Constructor nulo.
     */
	public BinNode()
	{
		left = null;
		right = null;
		token = null;
	}

    /**
     * Constructor que inicializa el nodo con un valor inicial.
     * @param n token inicial.
     */
	public BinNode(char n)
	{
		left = null;
		right = null;
		token = n;
	}

    /**
     * Inserta un hijo a la izquierda.
     * @param n Nodo hijo.
     */
	public void insertLeft(BinNode n)
	{
		left = n;
	}

    /**
     * Inserta un hijo a la izquierda.
     * @param n Nodo hijo.
     */
	public void insertRight(BinNode n)
	{
		right = n;
	}

    /**
     * Coloca en el nodo un valor para almacenar.
     * @param token valor a almacenar.
     */
	public void setToken(Character token) 
	{
		this.token = token;
	}

    /**
     * Devuelve el hijo izquierdo.
     * @return nodo izquierdo
     */
	public BinNode getLeft() 
	{
		return left;
	}

    /**
     * Devuelve el hijo derecho
     * @return nodo derecho
     */
	public BinNode getRight() 
	{
		return right;
	}

    /**
     * Devuelve el token almacenado.
     * @return token.
     */
	public Character getToken() 
	{
		return token;
	}


    /**
     * Imprime el árbol haciendo recorrido en orden.
     * @param node Nodo para iniciar.
     */
	public static void printInorder(BinNode node)
	{
		if (node == null)
			return;

		//Imprimir hijo izquierdo.
		printInorder(node.left);

		//Imprimir valor.
		System.out.print(node.token + " ");

		//Imprimir hijo derecho.
		printInorder(node.right);
	}

    /**
     * Función que evalúa un árbol de expresión utilizando la tabla de símbolos para obtener
     * el valor de verdad para cada variable.
     * @param root Raíz del árbol.
     * @param symbolTable Tabla de símbolos
     * @return Resultado de la fórmula o null si no pude evaluarse
     */
	public static Boolean evaluateTree(BinNode root, HashMap<Character, Boolean> symbolTable)
	{
        boolean left = false, right = false;

        if (root == null)
            return null;

        //Es una hoja
        if(root.left == null && root.right == null)
            return symbolTable.get(root.token);

        //Evalúa el subárbol izquierdo.
        if(root.left != null)
            left = evaluateTree(root.left, symbolTable);

        //Evalúa el subárbol derecho.
        if (root.right != null)
            right = evaluateTree(root.right, symbolTable);

        //Se chequea cuál operación se evaluará.
        switch (root.token)
        {
            case '→':
                return !left || right;
            case '^':
                return left && right;
            case '∨':
                return left || right;
            case '~':
                return !left;
            default:
                return null;
        }

	}

}
